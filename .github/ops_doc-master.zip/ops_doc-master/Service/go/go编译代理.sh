go编译代理



export GOPROXY="https://mirrors.aliyun.com/goproxy/"




