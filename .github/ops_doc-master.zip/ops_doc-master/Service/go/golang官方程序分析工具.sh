golang官方程序分析工具


go tool pprof http://127.0.0.1:xxxx/debug/pprof/profile