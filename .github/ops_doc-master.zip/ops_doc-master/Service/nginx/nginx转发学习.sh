nginx转发学习

http://pmghong.blog.51cto.com/3221425/1219391

http://breezey.blog.51cto.com/2400275/1339484

http://freeloda.blog.51cto.com/2033581/1288553