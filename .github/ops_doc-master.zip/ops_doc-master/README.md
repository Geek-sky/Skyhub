# ops_doc

  文档制作: left_left  小蜗牛  PF  雪松  rock  Jesse  sanm  Derek
  
  更新日期: 2016-04-28
  
  欢迎系统运维加入Q群: 198173206  # 加群请回答问题
  
  本文档手册希望可以达到通俗易懂, 方便运维人员使用, 错误在所难免, 还望指正！

  也希望大家能够在自己擅长的方面, 贡献一些通俗易懂实用的精品文档.万分感谢!
  
  文档请使用"notepad++"或其它编辑器打开此文档, "alt+0"将函数折叠后方便查阅
  
  github更新下载地址:  https://github.com/liquanzhou/ops_doc
  
  请勿删除信息, 转载请说明出处, 抵制不道德行为

# useful for beginners
